import IranMap from './components/IranMap';

export {IranMap};
